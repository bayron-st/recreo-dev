							 
							     
                                                        <nav>
                                                            <ul class="fancyNav" style="width:100%;">
                                                              <li id="news" class="opcionMenuB"><a href="participantes.php" class="opcionMenuB">Participantes</a></li>
                                                              <li id="news" class="opcionMenuB"><a href="tiendas.php" class="opcionMenuA">Tiendas</a></li>
                                                              <li id="news" class="opcionMenuB"><a href="creditos.php" class="opcionMenuA">Creditos</a></li>
                                                              <li id="news" class="opcionMenuB"><a href="canjes.php" class="opcionMenuA">Canjes</a></li>
                                                              <li id="news" class="opcionMenuE"><a href="salirLogin.php" class="opcionMenuB">Salir</a></li>
                                                            </ul>
                                                        </nav>   
							 